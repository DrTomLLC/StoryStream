// Future: Terminal UI with ratatui
// For now, using simple terminal output