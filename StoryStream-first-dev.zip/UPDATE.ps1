git add -A
git reset HEAD target/ Cargo.lock
git commit -m "fix: All tests passing - ready to push"
git push origin first-dev --force